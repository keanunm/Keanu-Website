import sys
import os
import json
import datetime
import subprocess

os.chdir(os.path.dirname(os.path.abspath(__file__)))

def log(log, logtype, extramessage):
    if logtype == "error":
        print(log)

    with open("logs/log.txt", "a") as file:
        file.write(f"[{str(datetime.datetime.now())}] {extramessage} {log}\n")

os.makedirs("logs", exist_ok=True)
os.makedirs("packages", exist_ok=True)
os.makedirs("projects", exist_ok=True)

try:
    import questionary as quest
except ImportError:
    log("""It appears that you do not have the library named questionary.
    It is a base dependency for the app to run. Install questionary in your
    terminal using the commands:

    'python -m pip install questionary'
    and if the first one doesn't work, try using:
    'py -m pip install questionary'""", "error", "[ERROR FROM DEPENDENCY]")
    sys.exit()

log("Dependencies installed", "status", "")

while True:
    Choice = quest.select(
        "MAIN MENU, Enter to confirm",
        choices=[
            "Create Project", #MADE
            "Load Project",
            "Delete Projects", #MADE
            "View Packages", #MADE
            "Exit" #MADE
        ]
    ).ask()

    log("User Chose: " + Choice, "log", "")

    if Choice == "View Packages":
        try:
            installed_packages = []
            for foldername in os.listdir("packages"):
                with open("packages/" + foldername + "/header.json", "r") as file:
                    data = json.load(file)
                    installed_packages.append(data["dependency_name"])

            Package = quest.select(
                "Which packages would you like to view? Installed Packages: ",
                choices=installed_packages
            ).ask()
            log(f"Viewed package {Package}", "log", "")

            with open(f"packages/{Package}/header.json", "r") as file:
                data = json.load(file)

                print(f"""
Dependency Name: {data["dependency_name"]}
{data["description"]}
Made by {data["author"]}
""")

        except:
            log("You do not have any packages", "error", "")

    if Choice == "Create Project":

        try:
            installed_packages = []

            name = input("What is the name of you project?")
            description = input("You may add a description to help collaborators (Optional)")

            for foldername in os.listdir("packages"):
                with open("packages/" + foldername + "/header.json", "r") as file:
                    data = json.load(file)
                    installed_packages.append(data["dependency_name"])
        
            Packages = quest.select(
                "Which packages would you like to view? Installed Packages: ",
                choices=installed_packages
            ).ask()
            log(f"Viewed package {Packages}", "log", "")
        except:
            log("You do not have any packages", "error", "")

        os.makedirs("projects/" + name)

        data = {}
        data["name"] = name
        data["description"] = description
        data["packages"] = Packages

        with open("projects/" + name + "/project_init.json", "w") as file:
            json.dump(data, file, indent=4)

    if Choice == "Delete Projects":
        try:
            projects = []
            for foldername in os.listdir("projects"):
                projects.append(foldername)

            Checkbox = quest.checkbox(
                "Select projects that you want to delete.",
                choices=projects
            ).ask()

            for item in Checkbox:
                subprocess.run(
                    ["cmd", "/c", "rmdir", "/s", "/q", os.path.join("projects", item)], 
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
        except:
            log("You do not have any projects to delete", "error", "")
    
    if Choice == "Exit":
        log("exited without error", "log", "")
        sys.exit()